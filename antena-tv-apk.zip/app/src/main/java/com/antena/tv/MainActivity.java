package com.antena.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int FILE_REQUEST = 7;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String appUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        appUrl = getString(R.string.app_url);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0E1013"));
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " AntenaApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showOffline(view);
                }
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.equals(appUrl)) {
                    showOffline(view);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQUEST);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,
                            "Esta tele no tiene un explorador de archivos. Usa «Añadir por enlace».",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        web.loadUrl(appUrl);
        web.requestFocus();
    }

    private void showOffline(WebView view) {
        String html = "<html><body style=\"background:#0e1013;color:#ebe8e2;font-family:sans-serif;"
                + "text-align:center;padding-top:14%\">"
                + "<h1>Sin conexión</h1>"
                + "<p>No se pudo abrir Antena. Revisa el internet de la tele.</p>"
                + "<p><a id=\"r\" href=\"" + appUrl + "\" style=\"display:inline-block;color:#0e1013;"
                + "background:#ffd23f;padding:14px 28px;border-radius:8px;text-decoration:none;"
                + "font-weight:bold\">Reintentar</a></p>"
                + "<script>document.getElementById('r').focus()</script>"
                + "</body></html>";
        view.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private void runJs(String code) {
        web.evaluateJavascript(code, null);
    }

    // El botón Atrás primero cierra lo que esté abierto dentro de la app. Si no hay nada, sale.
    private void handleBack() {
        web.evaluateJavascript("!!(window.__antenaBack && window.__antenaBack())", value -> {
            if (!"true".equals(value)) {
                finish();
            }
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int key = event.getKeyCode();
        if (key == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                handleBack();
            }
            return true;
        }
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            if (key == KeyEvent.KEYCODE_CHANNEL_UP) {
                runJs("window.__antenaCh && window.__antenaCh(1)");
                return true;
            }
            if (key == KeyEvent.KEYCODE_CHANNEL_DOWN) {
                runJs("window.__antenaCh && window.__antenaCh(-1)");
                return true;
            }
            if (key == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || key == KeyEvent.KEYCODE_MEDIA_PLAY
                    || key == KeyEvent.KEYCODE_MEDIA_PAUSE) {
                runJs("window.__antenaPlayPause && window.__antenaPlayPause()");
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
